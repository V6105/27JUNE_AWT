function b1(){
    document.getElementById('h1').style.fontfamily='Times New Roman';
   
}
function b2(){
    document.getElementById('h1').style.fontSize="200px";
    
}
function b3(){
    document.getElementById('h1').style.display="none";
    
}