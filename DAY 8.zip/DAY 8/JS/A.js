function alertinternal(){
    alert('hello');
    document.body.style.backgroundColor='red';
}
function confirminternal(){
    confirm('hello everyone');
    document.body.style.animation
}
function promptinternal(){
    prompt('hello guys');
}