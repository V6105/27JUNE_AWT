
$(document).ready(function() {
    $("#db").datepicker({
        showWeek: true ,
        yearSuffix:"(DOB)" ,
        showAnim: "slideDown",
       });
      
       $("#db1").datepicker();
       $("#db1").datepicker("show");



       $("#db2").datepicker({
        showWeek: true ,
        yearSuffix:"(DOB)" ,
        showAnim: "Fade in",
       });



       $("#db3").datepicker({
        showWeek: true ,
        yearSuffix:"(DOB)" ,
        showAnim: "Blind",
       });



       $("#db4").datepicker({
        showWeek: true ,
        yearSuffix:"(DOB)" ,
        showAnim: "Clip",
       });


       $("#db5").datepicker({
        showWeek: true ,
        yearSuffix:"(DOB)" ,
        showAnim: "Drop",
       });



       $("#db6").datepicker({
        showWeek: true ,
        yearSuffix:"(DOB)" ,
        showAnim: "Fold",
       });

       
       $("#db7").datepicker({
        showWeek: true ,
        yearSuffix:"(DOB)" ,
        showAnim: "Slide",
       });
      


       
    });