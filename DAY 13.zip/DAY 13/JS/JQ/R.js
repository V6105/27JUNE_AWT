$(document).ready(function(){
    $("#D1").dialog({
        autoOpen: true,
    });
    $("#D2").click(function(){
        $("#D1").dialog("open");
    });






});