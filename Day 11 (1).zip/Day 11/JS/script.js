$(document).ready(function(){
    $("#btn1").click(function(){
        $(".div1").hide();
        $(this).attr("disabled",true); 
        $("#btn2").attr("disabled",false);
      });
      $("#btn2").click(function(){
        $(".div1").show();
        $(this).attr("disabled",true); 
        $("#btn1").attr("disabled",false);
      });
      $("#btn3").click(function(){
        $(".div1").height("300px");
        $(".div1").width("300px");
        $(this).attr("disabled",true); 
        $("#btn4").attr("disabled",false);
    });
    $("#btn4").click(function(){
        $(".div1").height("100px");
        $(".div1").width("100px");
        $(this).attr("disabled",true); 
        $("#btn3").attr("disabled",false);
    });
    $("#btn5").click(function(){
            var x=parseInt($(".div1").css("height"));
            if(x<=500){
                x+=10;
                $(".div1").css("height",x);
                $(".div1").css("width",x);
            }
            else{
                $(this).attr("disabled",true); 
                $("#btn6").attr("disabled",false);
                alert("more then 500px is not possible");
            }

        });
        $("#btn6").click(function(){
            var y=parseInt($(".div1").css("height"));
            if(y>=30){
                y-=10;
                $(".div1").css("height",y);
                $(".div1").css("width",y);
            }
            else{
                $(this).attr("disabled",true); 
                $("#btn5").attr("disabled",false);
                alert("less then 30px is not possible");
            }

        });
    
        $("#bt1").click(function(){
            $("#div3").hide();
            $(this).attr("disabled",true); 
            $("#bt2").attr("disabled",false);

           
        });
        $("#bt2").click(function(){
            $("#div3").show();
            $(this).attr('disabled',true); 
            $("#bt1").attr('disabled',false);

        });
});


