$(document).ready(function(){
    $(".drag").draggable();
    $(".drop").droppable({
        accept: ".drag",
        drop: function(event , ui){
            $(this).addClass("MyClass").find("p").html("Done....")
        }
        
    });

    $(".b1").sortable();
    $(".b2").sortable();
    $(".b1").sortable({
        connectWith:".b2,.b1"
    });
    $(".b2").sortable({
        connectWith:" .b1, .b2"
   });

   $("#resize").resizable();

});